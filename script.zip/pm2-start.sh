#!/bin/bash

cd /var/www/html/eshop
pm2 start
